// Copyright (c) 2019 Nineva Studios

#pragma once

class StringUtils
{
public:

	static char* CopyString(FString str);
};